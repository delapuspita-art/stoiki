import { chatWithTutor, balanceEquationAI, generateQuizAI } from './services.js';

// Helper to create elements with classes and content
const el = (tag, classes = '', html = '') => {
  const element = document.createElement(tag);
  if (classes) element.className = classes;
  if (html) element.innerHTML = html;
  return element;
};

// --- Navbar Component ---
export function createNavbar(currentView, navigateFn) {
  const navItems = [
    { id: 'home', label: 'Beranda', icon: 'flask-conical' },
    { id: 'learn', label: 'Materi', icon: 'book-open' },
    { id: 'tools', label: 'Alat', icon: 'calculator' },
    { id: 'tutor', label: 'Tutor AI', icon: 'message-circle' },
    { id: 'quiz', label: 'Kuis', icon: 'brain-circuit' },
  ];

  const container = el('nav', 'bg-white border-b border-slate-200 sticky top-0 z-50');
  
  const content = `
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="flex justify-between h-16">
        <div class="flex items-center cursor-pointer" id="nav-logo">
          <div class="bg-emerald-600 p-2 rounded-lg mr-2">
            <i data-lucide="flask-conical" class="w-6 h-6 text-white"></i>
          </div>
          <span class="text-xl font-bold text-slate-800 tracking-tight">StoiKi</span>
        </div>
        
        <div class="hidden md:flex space-x-1" id="nav-desktop">
          <!-- Items injected here -->
        </div>

        <div class="flex md:hidden items-center">
          <div class="flex space-x-4" id="nav-mobile">
            <!-- Mobile items injected here -->
          </div>
        </div>
      </div>
    </div>
  `;
  container.innerHTML = content;

  // Add interactions
  container.querySelector('#nav-logo').addEventListener('click', () => navigateFn('home'));

  const desktopContainer = container.querySelector('#nav-desktop');
  const mobileContainer = container.querySelector('#nav-mobile');

  navItems.forEach(item => {
    // Desktop Button
    const btn = el('button', `flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors ${currentView === item.id ? 'bg-emerald-50 text-emerald-700' : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'}`);
    btn.innerHTML = `<i data-lucide="${item.icon}" class="w-5 h-5 mr-2"></i>${item.label}`;
    btn.onclick = () => navigateFn(item.id);
    if (item.id !== 'home') desktopContainer.appendChild(btn);

    // Mobile Button (icon only for non-home)
    if (item.id !== 'home') {
        const mobBtn = el('button', `p-2 rounded-md ${currentView === item.id ? 'text-emerald-600 bg-emerald-50' : 'text-slate-500'}`);
        mobBtn.innerHTML = `<i data-lucide="${item.icon}" class="w-5 h-5"></i>`;
        mobBtn.onclick = () => navigateFn(item.id);
        mobileContainer.appendChild(mobBtn);
    }
  });

  return container;
}

// --- Hero Component ---
export function createHero(navigateFn) {
  const container = el('div', 'relative overflow-hidden bg-white');
  container.innerHTML = `
    <div class="max-w-7xl mx-auto">
      <div class="relative z-10 pb-8 bg-white sm:pb-16 md:pb-20 lg:max-w-2xl lg:w-full lg:pb-28 xl:pb-32">
        <main class="mt-10 mx-auto max-w-7xl px-4 sm:mt-12 sm:px-6 md:mt-16 lg:mt-20 lg:px-8 xl:mt-28">
          <div class="sm:text-center lg:text-left">
            <h1 class="text-4xl tracking-tight font-extrabold text-slate-900 sm:text-5xl md:text-6xl">
              <span class="block xl:inline">Kuasai Kimia dengan</span>
              <span class="block text-emerald-600 xl:inline">Cerdas & Interaktif</span>
            </h1>
            <p class="mt-3 text-base text-slate-500 sm:mt-5 sm:text-lg sm:max-w-xl sm:mx-auto md:mt-5 md:text-xl lg:mx-0">
              Belajar Stoikiometri tidak pernah semudah ini. Gunakan alat bantu AI untuk menyeimbangkan reaksi, tutor pribadi 24/7, dan latihan soal yang adaptif.
            </p>
            <div class="mt-5 sm:mt-8 sm:flex sm:justify-center lg:justify-start">
              <div class="rounded-md shadow">
                <button id="hero-start" class="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-emerald-600 hover:bg-emerald-700 md:py-4 md:text-lg md:px-10">
                  Mulai Belajar
                </button>
              </div>
              <div class="mt-3 sm:mt-0 sm:ml-3">
                <button id="hero-tools" class="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-emerald-700 bg-emerald-100 hover:bg-emerald-200 md:py-4 md:text-lg md:px-10">
                  Coba Alat AI
                </button>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
    <div class="lg:absolute lg:inset-y-0 lg:right-0 lg:w-1/2 bg-slate-50 flex items-center justify-center">
      <div class="p-8 grid grid-cols-2 gap-4 opacity-80">
          <div class="bg-white p-6 rounded-2xl shadow-lg transform translate-y-4">
              <i data-lucide="zap" class="text-yellow-500 w-10 h-10 mb-4"></i>
              <h3 class="font-bold text-slate-800">Cepat</h3>
              <p class="text-sm text-slate-500">Penyetaraan reaksi instan</p>
          </div>
          <div class="bg-white p-6 rounded-2xl shadow-lg transform -translate-y-4">
              <i data-lucide="check-circle" class="text-emerald-500 w-10 h-10 mb-4"></i>
              <h3 class="font-bold text-slate-800">Akurat</h3>
              <p class="text-sm text-slate-500">Penjelasan langkah demi langkah</p>
          </div>
           <div class="bg-white p-6 rounded-2xl shadow-lg transform translate-y-4">
              <div class="text-blue-500 text-2xl font-bold mb-2">H₂O</div>
              <h3 class="font-bold text-slate-800">Visual</h3>
              <p class="text-sm text-slate-500">Memahami konsep mol</p>
          </div>
           <div class="bg-white p-6 rounded-2xl shadow-lg transform -translate-y-4">
              <div class="text-purple-500 text-2xl font-bold mb-2">6.02</div>
              <h3 class="font-bold text-slate-800">Lengkap</h3>
              <p class="text-sm text-slate-500">Konstanta Avogadro & lainnya</p>
          </div>
      </div>
    </div>
  `;

  container.querySelector('#hero-start').onclick = () => navigateFn('learn');
  container.querySelector('#hero-tools').onclick = () => navigateFn('tools');

  return container;
}

// --- Learn Component ---
export function createLearn() {
  const container = el('div', 'max-w-4xl mx-auto px-4 py-8');
  container.innerHTML = `<h2 class="text-3xl font-bold text-slate-800 mb-6 text-center">Materi Dasar Stoikiometri</h2><div id="topics-container" class="space-y-4"></div>`;
  
  const topicsContainer = container.querySelector('#topics-container');

  const topics = [
    {
      id: 1,
      title: "Konsep Mol",
      icon: "database",
      iconColor: "text-purple-500",
      content: `
        <div class="space-y-4">
          <p><strong>Mol</strong> adalah satuan dasar dalam kimia untuk menyatakan jumlah zat. Satu mol zat mengandung jumlah partikel yang sama dengan jumlah atom dalam 12 gram isotop karbon-12.</p>
          <div class="bg-purple-50 p-4 rounded-lg border border-purple-100">
            <h4 class="font-bold text-purple-800">Bilangan Avogadro (L)</h4>
            <p class="text-2xl font-mono text-center my-2 text-purple-900">6,02 × 10²³</p>
            <p class="text-sm text-purple-700">Artinya, 1 mol air mengandung 6,02 × 10²³ molekul air.</p>
          </div>
          <p>Rumus dasar:</p>
          <ul class="list-disc list-inside text-slate-700 bg-white p-4 rounded shadow-sm">
            <li>n = jumlah partikel / L</li>
            <li>n = massa (gr) / Mr atau Ar</li>
          </ul>
        </div>
      `
    },
    {
      id: 2,
      title: "Massa Molar (Mr & Ar)",
      icon: "scale",
      iconColor: "text-emerald-500",
      content: `
        <div class="space-y-4">
          <p><strong>Massa Atom Relatif (Ar)</strong> adalah perbandingan massa rata-rata satu atom unsur terhadap 1/12 massa atom C-12.</p>
          <p><strong>Massa Molekul Relatif (Mr)</strong> adalah jumlah total Ar dari semua atom penyusun molekul tersebut.</p>
          <div class="bg-emerald-50 p-4 rounded-lg border border-emerald-100">
            <h4 class="font-bold text-emerald-800">Contoh: H₂O</h4>
            <p class="text-sm text-emerald-700 mt-2">
              Diketahui Ar H = 1, O = 16.<br/>
              Mr H₂O = (2 × Ar H) + (1 × Ar O)<br/>
              Mr H₂O = (2 × 1) + 16 = <strong>18 g/mol</strong>
            </p>
          </div>
        </div>
      `
    },
    {
      id: 3,
      title: "Persamaan Reaksi",
      icon: "test-tube",
      iconColor: "text-blue-500",
      content: `
        <div class="space-y-4">
          <p>Persamaan reaksi menggambarkan perubahan kimia dari <strong>Pereaksi (Reaktan)</strong> menjadi <strong>Hasil Reaksi (Produk)</strong>.</p>
          <div class="bg-blue-50 p-4 rounded-lg border border-blue-100 flex items-center justify-center space-x-4">
             <div class="text-center">
               <span class="font-bold text-blue-900">Reaktan</span>
               <div class="text-sm text-blue-600">Sebelah Kiri</div>
             </div>
             <div class="text-2xl text-blue-400">→</div>
             <div class="text-center">
               <span class="font-bold text-blue-900">Produk</span>
               <div class="text-sm text-blue-600">Sebelah Kanan</div>
             </div>
          </div>
          <p class="text-slate-700"><strong>Hukum Kekekalan Massa (Lavoisier):</strong> Massa zat sebelum dan sesudah reaksi adalah sama. Oleh karena itu, jumlah atom tiap unsur di kiri dan kanan panah harus sama (Setara).</p>
        </div>
      `
    }
  ];

  topics.forEach(topic => {
    const item = el('div', 'bg-white rounded-xl shadow-md overflow-hidden border border-slate-100');
    // Default open first topic
    const isOpen = topic.id === 1;
    
    item.innerHTML = `
      <button class="topic-btn w-full px-6 py-4 flex items-center justify-between bg-slate-50 hover:bg-slate-100 transition-colors focus:outline-none">
        <div class="flex items-center space-x-3">
          <i data-lucide="${topic.icon}" class="w-6 h-6 ${topic.iconColor}"></i>
          <span class="font-semibold text-lg text-slate-800">${topic.title}</span>
        </div>
        <i data-lucide="${isOpen ? 'chevron-up' : 'chevron-down'}" class="w-5 h-5 text-slate-500 icon-chevron"></i>
      </button>
      <div class="topic-content px-6 py-6 animate-fadeIn prose prose-slate max-w-none text-slate-600 leading-relaxed ${isOpen ? '' : 'hidden'}">
        ${topic.content}
      </div>
    `;

    // Toggle Logic
    const btn = item.querySelector('.topic-btn');
    const contentDiv = item.querySelector('.topic-content');
    const chevron = item.querySelector('.icon-chevron');

    btn.onclick = () => {
      const isHidden = contentDiv.classList.contains('hidden');
      if (isHidden) {
        contentDiv.classList.remove('hidden');
        chevron.setAttribute('data-lucide', 'chevron-up');
      } else {
        contentDiv.classList.add('hidden');
        chevron.setAttribute('data-lucide', 'chevron-down');
      }
      lucide.createIcons({ root: item });
    };

    topicsContainer.appendChild(item);
  });

  return container;
}

// --- Tools Component ---
export function createTools() {
  const container = el('div', 'max-w-4xl mx-auto px-4 py-8');
  container.innerHTML = `
    <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
      <div class="bg-emerald-600 px-6 py-8 text-white text-center">
        <i data-lucide="flask-conical" class="w-12 h-12 mx-auto mb-4 opacity-90"></i>
        <h2 class="text-3xl font-bold">Lab Kimia AI</h2>
        <p class="mt-2 text-emerald-100">Seimbangkan reaksi kimia dan hitung massa molar secara otomatis.</p>
      </div>

      <div class="p-8">
        <form id="balance-form" class="mb-8">
          <label class="block text-sm font-medium text-slate-700 mb-2">
            Masukkan Persamaan Reaksi (contoh: H2 + O2 = H2O)
          </label>
          <div class="flex gap-2">
            <input
              type="text"
              id="eq-input"
              placeholder="Misal: C3H8 + O2 -> CO2 + H2O"
              class="flex-1 rounded-lg border border-slate-300 px-4 py-3 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition"
            />
            <button
              type="submit"
              id="submit-btn"
              class="bg-emerald-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed transition flex items-center"
            >
              Proses
            </button>
          </div>
        </form>

        <div id="error-box" class="hidden bg-red-50 border-l-4 border-red-500 p-4 mb-6">
          <p class="text-red-700" id="error-msg"></p>
        </div>

        <div id="result-box" class="hidden space-y-6 animate-fadeIn">
          <!-- Populated by JS -->
        </div>
      </div>
    </div>
  `;

  const form = container.querySelector('#balance-form');
  const input = container.querySelector('#eq-input');
  const submitBtn = container.querySelector('#submit-btn');
  const errorBox = container.querySelector('#error-box');
  const errorMsg = container.querySelector('#error-msg');
  const resultBox = container.querySelector('#result-box');

  form.onsubmit = async (e) => {
    e.preventDefault();
    if (!input.value.trim()) return;

    // Loading State
    submitBtn.disabled = true;
    submitBtn.innerHTML = `<i data-lucide="loader-2" class="w-5 h-5 animate-spin"></i>`;
    lucide.createIcons({ root: submitBtn });
    errorBox.classList.add('hidden');
    resultBox.classList.add('hidden');
    resultBox.innerHTML = '';

    try {
      const result = await balanceEquationAI(input.value);
      
      // Render Result
      resultBox.innerHTML = `
        <div class="bg-slate-50 border border-slate-200 rounded-xl p-6">
          <h3 class="text-sm font-bold text-slate-500 uppercase tracking-wide mb-2">Persamaan Setara</h3>
          <div class="text-2xl md:text-3xl font-mono text-emerald-700 bg-white p-4 rounded-lg shadow-sm border border-emerald-100 overflow-x-auto">
            ${result.balancedEquation}
          </div>
        </div>

        <div class="grid md:grid-cols-2 gap-6">
          <div class="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
            <h3 class="text-lg font-bold text-slate-800 mb-4 flex items-center">
              <i data-lucide="arrow-right" class="w-5 h-5 mr-2 text-emerald-500"></i>
              Langkah Penyetaraan
            </h3>
            <ul class="space-y-3">
              ${result.steps.map((step, idx) => `
                <li class="flex items-start text-slate-600 text-sm">
                  <span class="bg-emerald-100 text-emerald-800 text-xs font-bold px-2 py-1 rounded-full mr-3 mt-0.5">${idx + 1}</span>
                  ${step}
                </li>
              `).join('')}
            </ul>
          </div>

          <div class="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
             <h3 class="text-lg font-bold text-slate-800 mb-4">Massa Molar (Mr)</h3>
             <div class="divide-y divide-slate-100">
                ${Object.entries(result.molarMasses).map(([compound, mass]) => `
                  <div class="py-2 flex justify-between items-center">
                    <span class="font-mono text-slate-700 font-semibold">${compound}</span>
                    <span class="text-slate-500">${mass}</span>
                  </div>
                `).join('')}
             </div>
          </div>
        </div>
      `;
      resultBox.classList.remove('hidden');
      lucide.createIcons({ root: resultBox });

    } catch (err) {
      errorBox.classList.remove('hidden');
      errorMsg.textContent = err.message || "Terjadi kesalahan";
    } finally {
      submitBtn.disabled = false;
      submitBtn.innerText = 'Proses';
    }
  };

  return container;
}

// --- Tutor Component ---
export function createTutor() {
  const container = el('div', 'max-w-4xl mx-auto px-4 py-8 h-[calc(100vh-4rem)]');
  
  // Internal State
  let messages = [
    { role: 'model', content: "Halo! Saya StoiKi Bot. Ada yang bisa saya bantu tentang Stoikiometri hari ini?" }
  ];

  container.innerHTML = `
    <div class="bg-white rounded-2xl shadow-xl overflow-hidden h-full flex flex-col border border-slate-200">
      <div class="bg-indigo-600 p-4 text-white flex items-center shadow-sm">
        <i data-lucide="bot" class="w-8 h-8 mr-3"></i>
        <div>
          <h2 class="text-lg font-bold">Tutor Pribadi AI</h2>
          <p class="text-indigo-200 text-xs">Selalu siap membantu 24/7</p>
        </div>
      </div>

      <div id="chat-messages" class="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50"></div>

      <form id="chat-form" class="p-4 bg-white border-t border-slate-100 flex gap-2">
        <input
          type="text"
          id="chat-input"
          placeholder="Tanya tentang mol, rumus, atau soal..."
          class="flex-1 rounded-full border border-slate-300 px-5 py-3 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition text-sm"
        />
        <button
          type="submit"
          id="chat-btn"
          class="bg-indigo-600 text-white p-3 rounded-full hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition"
        >
          <i data-lucide="send" class="w-5 h-5"></i>
        </button>
      </form>
    </div>
  `;

  const messagesContainer = container.querySelector('#chat-messages');
  const form = container.querySelector('#chat-form');
  const input = container.querySelector('#chat-input');
  const btn = container.querySelector('#chat-btn');

  const renderMessage = (msg) => {
    const isUser = msg.role === 'user';
    const div = el('div', `flex ${isUser ? 'justify-end' : 'justify-start'}`);
    div.innerHTML = `
      <div class="flex max-w-[80%] ${isUser ? 'flex-row-reverse' : 'flex-row'}">
        <div class="flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center ${isUser ? 'bg-emerald-500 ml-2' : 'bg-indigo-500 mr-2'}">
          <i data-lucide="${isUser ? 'user' : 'bot'}" class="w-5 h-5 text-white"></i>
        </div>
        <div class="px-4 py-3 rounded-2xl text-sm ${isUser ? 'bg-emerald-600 text-white rounded-tr-none' : 'bg-white text-slate-700 border border-slate-200 rounded-tl-none shadow-sm'}">
          <p class="whitespace-pre-wrap">${msg.content}</p>
        </div>
      </div>
    `;
    messagesContainer.appendChild(div);
    lucide.createIcons({ root: div });
    div.scrollIntoView({ behavior: 'smooth' });
  };

  // Initial render
  messages.forEach(renderMessage);

  form.onsubmit = async (e) => {
    e.preventDefault();
    const txt = input.value.trim();
    if (!txt || btn.disabled) return;

    // User Message
    const userMsg = { role: 'user', content: txt };
    messages.push(userMsg);
    renderMessage(userMsg);
    input.value = '';
    btn.disabled = true;

    // Loading indicator
    const loadingDiv = el('div', 'flex justify-start', `
       <div class="flex flex-row">
         <div class="flex-shrink-0 h-8 w-8 rounded-full bg-indigo-500 mr-2 flex items-center justify-center">
            <i data-lucide="bot" class="w-5 h-5 text-white"></i>
         </div>
         <div class="bg-white px-4 py-3 rounded-2xl rounded-tl-none border border-slate-200 shadow-sm flex items-center">
           <i data-lucide="loader-2" class="w-4 h-4 text-indigo-500 animate-spin mr-2"></i>
           <span class="text-slate-400 text-sm">Sedang mengetik...</span>
         </div>
       </div>
    `);
    messagesContainer.appendChild(loadingDiv);
    lucide.createIcons({ root: loadingDiv });
    loadingDiv.scrollIntoView();

    try {
      const responseText = await chatWithTutor(messages, txt);
      // Remove loading
      messagesContainer.removeChild(loadingDiv);
      
      const botMsg = { role: 'model', content: responseText };
      messages.push(botMsg);
      renderMessage(botMsg);
    } catch (err) {
      messagesContainer.removeChild(loadingDiv);
      renderMessage({ role: 'model', content: "Error: " + err.message });
    } finally {
      btn.disabled = false;
      input.focus();
    }
  };

  return container;
}

// --- Quiz Component ---
export function createQuiz() {
  const container = el('div', 'max-w-3xl mx-auto px-4 py-8');
  let questions = [];
  let currentIndex = 0;
  let score = 0;
  let selectedOption = null;
  let isAnswered = false;
  let difficulty = 'medium';

  const renderIntro = () => {
    container.innerHTML = `
      <div class="max-w-2xl mx-auto px-4 py-12 text-center">
        <div class="bg-white rounded-2xl shadow-xl p-8 border border-slate-100">
          <i data-lucide="brain-circuit" class="w-16 h-16 text-emerald-600 mx-auto mb-6"></i>
          <h2 class="text-3xl font-bold text-slate-800 mb-4">Uji Pemahaman Stoikiometri</h2>
          <p class="text-slate-600 mb-8">Pilih tingkat kesulitan dan biarkan AI membuatkan kuis unik untukmu setiap saat.</p>
          
          <div class="flex justify-center space-x-4 mb-8">
            <button class="diff-btn px-4 py-2 rounded-lg capitalize border bg-white text-slate-600 border-slate-300 hover:bg-slate-50" data-diff="easy">Mudah</button>
            <button class="diff-btn px-4 py-2 rounded-lg capitalize border bg-emerald-600 text-white border-emerald-600" data-diff="medium">Sedang</button>
            <button class="diff-btn px-4 py-2 rounded-lg capitalize border bg-white text-slate-600 border-slate-300 hover:bg-slate-50" data-diff="hard">Sulit</button>
          </div>

          <button id="start-quiz-btn" class="w-full sm:w-auto px-8 py-3 bg-emerald-600 text-white rounded-full font-bold shadow-lg hover:bg-emerald-700 hover:shadow-xl transition transform hover:-translate-y-1">
            Mulai Kuis
          </button>
        </div>
      </div>
    `;
    lucide.createIcons({ root: container });

    // Difficulty selection logic
    const btns = container.querySelectorAll('.diff-btn');
    btns.forEach(btn => {
      btn.onclick = () => {
        difficulty = btn.dataset.diff;
        btns.forEach(b => {
          if (b.dataset.diff === difficulty) {
            b.className = "diff-btn px-4 py-2 rounded-lg capitalize border bg-emerald-600 text-white border-emerald-600";
          } else {
            b.className = "diff-btn px-4 py-2 rounded-lg capitalize border bg-white text-slate-600 border-slate-300 hover:bg-slate-50";
          }
        });
      };
    });

    container.querySelector('#start-quiz-btn').onclick = async () => {
      container.innerHTML = `
        <div class="flex flex-col items-center justify-center min-h-[50vh]">
          <i data-lucide="brain-circuit" class="w-16 h-16 text-emerald-500 animate-pulse mb-4"></i>
          <p class="text-lg text-slate-600 font-medium">AI sedang menyusun soal untukmu...</p>
        </div>
      `;
      lucide.createIcons({ root: container });
      
      questions = await generateQuizAI(difficulty);
      score = 0;
      currentIndex = 0;
      renderQuestion();
    };
  };

  const renderQuestion = () => {
    isAnswered = false;
    selectedOption = null;
    const q = questions[currentIndex];

    container.innerHTML = `
      <div class="bg-white rounded-2xl shadow-lg overflow-hidden border border-slate-200">
        <div class="w-full bg-slate-100 h-2">
          <div class="bg-emerald-500 h-2 transition-all duration-300" style="width: ${((currentIndex + 1) / questions.length) * 100}%"></div>
        </div>
        <div class="p-6 md:p-8">
          <div class="flex justify-between items-center mb-6">
            <span class="text-sm font-bold text-slate-400">Soal ${currentIndex + 1} dari ${questions.length}</span>
            <span class="px-2 py-1 rounded text-xs font-bold uppercase bg-slate-100 text-slate-600">${difficulty}</span>
          </div>

          <h3 class="text-xl font-medium text-slate-800 mb-8 leading-relaxed">${q.question}</h3>
          
          <div id="options-container" class="space-y-3"></div>

          <div id="explanation-container" class="mt-6 hidden animate-fadeIn">
            <div class="bg-blue-50 border border-blue-100 p-4 rounded-lg mb-6">
              <h4 class="font-bold text-blue-800 mb-1">Penjelasan:</h4>
              <p class="text-blue-700 text-sm">${q.explanation}</p>
            </div>
            <div class="flex justify-end">
              <button id="next-btn" class="bg-emerald-600 text-white px-6 py-2 rounded-lg font-bold hover:bg-emerald-700 transition">
                ${currentIndex === questions.length - 1 ? 'Lihat Hasil' : 'Lanjut'}
              </button>
            </div>
          </div>
        </div>
      </div>
    `;

    const optsContainer = container.querySelector('#options-container');
    
    q.options.forEach((opt, idx) => {
      const btn = el('button', 'w-full text-left p-4 rounded-xl border-2 border-slate-200 hover:border-emerald-500 hover:bg-slate-50 text-slate-700 transition-all duration-200 flex justify-between items-center');
      btn.innerHTML = `<span>${opt}</span>`;
      btn.onclick = () => {
        if (isAnswered) return;
        isAnswered = true;
        selectedOption = idx;
        
        // Update Styles
        const allBtns = optsContainer.querySelectorAll('button');
        allBtns.forEach((b, i) => {
          b.disabled = true;
          if (i === q.correctIndex) {
            b.className = "w-full text-left p-4 rounded-xl border-2 border-green-500 bg-green-50 text-green-800 flex justify-between items-center";
            b.innerHTML += `<i data-lucide="check-circle" class="w-5 h-5 text-green-600"></i>`;
          } else if (i === idx) {
            b.className = "w-full text-left p-4 rounded-xl border-2 border-red-500 bg-red-50 text-red-800 flex justify-between items-center";
            b.innerHTML += `<i data-lucide="x-circle" class="w-5 h-5 text-red-600"></i>`;
          } else {
             b.className = "w-full text-left p-4 rounded-xl border-2 border-slate-100 text-slate-400 flex justify-between items-center";
          }
        });

        if (idx === q.correctIndex) score++;
        
        container.querySelector('#explanation-container').classList.remove('hidden');
        lucide.createIcons({ root: container });
      };
      optsContainer.appendChild(btn);
    });

    container.querySelector('#next-btn').onclick = () => {
      if (currentIndex < questions.length - 1) {
        currentIndex++;
        renderQuestion();
      } else {
        renderResult();
      }
    };
  };

  const renderResult = () => {
    container.innerHTML = `
      <div class="max-w-2xl mx-auto px-4 py-12 text-center animate-fadeIn">
        <div class="bg-white rounded-2xl shadow-xl p-8 border border-slate-100">
          <i data-lucide="award" class="w-20 h-20 text-yellow-500 mx-auto mb-6"></i>
          <h2 class="text-3xl font-bold text-slate-800 mb-2">Kuis Selesai!</h2>
          <p class="text-slate-600 mb-6">Kamu mendapatkan skor:</p>
          <div class="text-6xl font-bold text-emerald-600 mb-8">
            ${Math.round((score / questions.length) * 100)}
          </div>
          <p class="text-slate-500 mb-8">Benar ${score} dari ${questions.length} soal</p>
          
          <button id="retry-btn" class="flex items-center justify-center mx-auto px-6 py-3 border-2 border-slate-300 text-slate-700 font-bold rounded-lg hover:border-slate-800 hover:text-slate-800 transition">
            <i data-lucide="rotate-ccw" class="w-5 h-5 mr-2"></i>
            Coba Lagi
          </button>
        </div>
      </div>
    `;
    lucide.createIcons({ root: container });
    container.querySelector('#retry-btn').onclick = () => renderIntro();
  };

  renderIntro();
  return container;
}
