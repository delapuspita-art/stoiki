import { createNavbar, createHero, createLearn, createTools, createTutor, createQuiz } from './components.js';

class App {
  constructor() {
    this.root = document.getElementById('app');
    this.currentView = 'home';
    this.render();
  }

  setView(view) {
    this.currentView = view;
    this.render();
  }

  render() {
    this.root.innerHTML = '';
    
    // Navbar
    const navbar = createNavbar(this.currentView, (view) => this.setView(view));
    this.root.appendChild(navbar);

    // Main Content
    const main = document.createElement('main');
    main.className = "flex-1 transition-opacity duration-300 ease-in-out";
    
    let viewElement;
    switch (this.currentView) {
      case 'home':
        viewElement = createHero((view) => this.setView(view));
        break;
      case 'learn':
        viewElement = createLearn();
        break;
      case 'tools':
        viewElement = createTools();
        break;
      case 'tutor':
        viewElement = createTutor();
        break;
      case 'quiz':
        viewElement = createQuiz();
        break;
      default:
        viewElement = createHero((view) => this.setView(view));
    }
    
    main.appendChild(viewElement);
    this.root.appendChild(main);

    // Footer
    const footer = document.createElement('footer');
    footer.className = "bg-white border-t border-slate-200 mt-12 py-8";
    footer.innerHTML = `
      <div class="max-w-7xl mx-auto px-4 text-center text-slate-400 text-sm">
        <p>&copy; ${new Date().getFullYear()} StoiKi. Dibuat dengan Vanilla JS & Gemini AI.</p>
      </div>
    `;
    this.root.appendChild(footer);

    // Initialize Icons
    if (window.lucide) {
      window.lucide.createIcons();
    }
  }
}

// Initialize App when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  new App();
});
