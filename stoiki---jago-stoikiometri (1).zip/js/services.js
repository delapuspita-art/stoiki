import { GoogleGenAI } from "@google/genai";

// Use the API key from the window.process shim defined in index.html
const apiKey = process.env.API_KEY || '';

const ai = new GoogleGenAI({ apiKey });
const modelName = 'gemini-2.5-flash';

// Helper to handle Enum types which might differ in the ESM import
const Type = {
  STRING: 'STRING',
  NUMBER: 'NUMBER',
  INTEGER: 'INTEGER',
  BOOLEAN: 'BOOLEAN',
  ARRAY: 'ARRAY',
  OBJECT: 'OBJECT'
};

export const chatWithTutor = async (history, message) => {
  try {
    const chat = ai.chats.create({
      model: modelName,
      config: {
        systemInstruction: "Anda adalah 'StoiKi Bot', guru kimia SMA yang ramah, sabar, dan ahli dalam Stoikiometri. Jelaskan konsep dengan analogi sederhana sehari-hari. Gunakan Bahasa Indonesia yang baik. Jika siswa bertanya soal hitungan, pandu mereka langkah demi langkah, jangan langsung beri jawaban akhir. Fokus pada konsep Mol, Massa Molar, Volume Molar, dan Penyetaraan Reaksi.",
      },
      history: history.map(h => ({ role: h.role, parts: [{ text: h.content }] })),
    });

    const response = await chat.sendMessage({ message });
    return response.text || "Maaf, saya sedang mengalami gangguan sebentar. Coba tanya lagi ya!";
  } catch (error) {
    console.error("Chat Error:", error);
    return "Terjadi kesalahan saat menghubungi server AI. Pastikan koneksi internet lancar dan API Key sudah diatur.";
  }
};

export const balanceEquationAI = async (equation) => {
  const schema = {
    type: Type.OBJECT,
    properties: {
      balancedEquation: { type: Type.STRING, description: "The fully balanced chemical equation with state symbols if possible." },
      steps: { 
        type: Type.ARRAY, 
        items: { type: Type.STRING },
        description: "Step-by-step explanation of how to balance it in Indonesian."
      },
      molarMasses: {
        type: Type.OBJECT,
        description: "Key-value pair of compound formulas and their molar masses (g/mol).",
        properties: {}
      }
    },
    required: ["balancedEquation", "steps", "molarMasses"]
  };

  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: `Balance this chemical equation and calculate molar masses: ${equation}. Explain in Indonesian.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response");
    return JSON.parse(text);
  } catch (error) {
    console.error("Balance Error:", error);
    throw new Error("Gagal menyeimbangkan reaksi. Pastikan rumus kimia benar.");
  }
};

export const generateQuizAI = async (difficulty) => {
  const schema = {
    type: Type.ARRAY,
    items: {
      type: Type.OBJECT,
      properties: {
        question: { type: Type.STRING, description: "The quiz question text in Indonesian." },
        options: { 
          type: Type.ARRAY, 
          items: { type: Type.STRING },
          description: "4 multiple choice options." 
        },
        correctIndex: { type: Type.INTEGER, description: "Index of the correct answer (0-3)." },
        explanation: { type: Type.STRING, description: "Explanation of the correct answer in Indonesian." }
      },
      required: ["question", "options", "correctIndex", "explanation"]
    }
  };

  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: `Generate 5 ${difficulty} stoichiometry chemistry questions for high school students in Indonesian. Focus on mole concept, balancing equations, and mass-mole conversions.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response");
    return JSON.parse(text);
  } catch (error) {
    console.error("Quiz Error:", error);
    return [
      {
        question: "Berapakah bilangan Avogadro?",
        options: ["6.02 x 10^23", "6.02 x 10^-23", "3.14 x 10^23", "1.66 x 10^-24"],
        correctIndex: 0,
        explanation: "Bilangan Avogadro adalah 6.02 x 10^23 partikel/mol."
      }
    ];
  }
};
