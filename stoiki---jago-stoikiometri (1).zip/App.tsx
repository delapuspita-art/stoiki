import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import LearnModule from './components/LearnModule';
import ToolsModule from './components/ToolsModule';
import TutorModule from './components/TutorModule';
import QuizModule from './components/QuizModule';
import { ViewState } from './types';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>('home');

  const renderView = () => {
    switch (currentView) {
      case 'home':
        return <Hero setView={setCurrentView} />;
      case 'learn':
        return <LearnModule />;
      case 'tools':
        return <ToolsModule />;
      case 'tutor':
        return <TutorModule />;
      case 'quiz':
        return <QuizModule />;
      default:
        return <Hero setView={setCurrentView} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar currentView={currentView} setView={setCurrentView} />
      <main className="transition-opacity duration-300 ease-in-out">
        {renderView()}
      </main>
      
      <footer className="bg-white border-t border-slate-200 mt-12 py-8">
        <div className="max-w-7xl mx-auto px-4 text-center text-slate-400 text-sm">
          <p>&copy; {new Date().getFullYear()} StoiKi. Dibuat dengan React & Gemini AI.</p>
        </div>
      </footer>
    </div>
  );
};

export default App;
