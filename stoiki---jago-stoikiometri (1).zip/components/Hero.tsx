import React from 'react';
import { ArrowRight, Zap, CheckCircle } from 'lucide-react';
import { ViewState } from '../types';

interface HeroProps {
  setView: (view: ViewState) => void;
}

const Hero: React.FC<HeroProps> = ({ setView }) => {
  return (
    <div className="relative overflow-hidden bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="relative z-10 pb-8 bg-white sm:pb-16 md:pb-20 lg:max-w-2xl lg:w-full lg:pb-28 xl:pb-32">
          <main className="mt-10 mx-auto max-w-7xl px-4 sm:mt-12 sm:px-6 md:mt-16 lg:mt-20 lg:px-8 xl:mt-28">
            <div className="sm:text-center lg:text-left">
              <h1 className="text-4xl tracking-tight font-extrabold text-slate-900 sm:text-5xl md:text-6xl">
                <span className="block xl:inline">Kuasai Kimia dengan</span>{' '}
                <span className="block text-emerald-600 xl:inline">Cerdas & Interaktif</span>
              </h1>
              <p className="mt-3 text-base text-slate-500 sm:mt-5 sm:text-lg sm:max-w-xl sm:mx-auto md:mt-5 md:text-xl lg:mx-0">
                Belajar Stoikiometri tidak pernah semudah ini. Gunakan alat bantu AI untuk menyeimbangkan reaksi, tutor pribadi 24/7, dan latihan soal yang adaptif.
              </p>
              <div className="mt-5 sm:mt-8 sm:flex sm:justify-center lg:justify-start">
                <div className="rounded-md shadow">
                  <button
                    onClick={() => setView('learn')}
                    className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-emerald-600 hover:bg-emerald-700 md:py-4 md:text-lg md:px-10"
                  >
                    Mulai Belajar
                  </button>
                </div>
                <div className="mt-3 sm:mt-0 sm:ml-3">
                  <button
                    onClick={() => setView('tools')}
                    className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-emerald-700 bg-emerald-100 hover:bg-emerald-200 md:py-4 md:text-lg md:px-10"
                  >
                    Coba Alat AI
                  </button>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
      <div className="lg:absolute lg:inset-y-0 lg:right-0 lg:w-1/2 bg-slate-50 flex items-center justify-center">
        <div className="p-8 grid grid-cols-2 gap-4 opacity-80">
            <div className="bg-white p-6 rounded-2xl shadow-lg transform translate-y-4">
                <Zap className="text-yellow-500 w-10 h-10 mb-4" />
                <h3 className="font-bold text-slate-800">Cepat</h3>
                <p className="text-sm text-slate-500">Penyetaraan reaksi instan</p>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-lg transform -translate-y-4">
                <CheckCircle className="text-emerald-500 w-10 h-10 mb-4" />
                <h3 className="font-bold text-slate-800">Akurat</h3>
                <p className="text-sm text-slate-500">Penjelasan langkah demi langkah</p>
            </div>
             <div className="bg-white p-6 rounded-2xl shadow-lg transform translate-y-4">
                <div className="text-blue-500 text-2xl font-bold mb-2">H₂O</div>
                <h3 className="font-bold text-slate-800">Visual</h3>
                <p className="text-sm text-slate-500">Memahami konsep mol</p>
            </div>
             <div className="bg-white p-6 rounded-2xl shadow-lg transform -translate-y-4">
                <div className="text-purple-500 text-2xl font-bold mb-2">6.02</div>
                <h3 className="font-bold text-slate-800">Lengkap</h3>
                <p className="text-sm text-slate-500">Konstanta Avogadro & lainnya</p>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
