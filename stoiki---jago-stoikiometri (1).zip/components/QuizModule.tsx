import React, { useState } from 'react';
import { generateQuizAI } from '../services/geminiService';
import { QuizQuestion, QuizResult } from '../types';
import { CheckCircle, XCircle, BrainCircuit, RotateCcw, Award } from 'lucide-react';

const QuizModule: React.FC = () => {
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [loading, setLoading] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');

  const startQuiz = async () => {
    setLoading(true);
    setQuestions([]);
    setCurrentIndex(0);
    setScore(0);
    setQuizFinished(false);
    setIsAnswered(false);
    setSelectedOption(null);

    try {
      const qs = await generateQuizAI(difficulty);
      setQuestions(qs);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleOptionClick = (index: number) => {
    if (isAnswered) return;
    setSelectedOption(index);
    setIsAnswered(true);

    if (index === questions[currentIndex].correctIndex) {
      setScore(s => s + 1);
    }
  };

  const nextQuestion = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(c => c + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      setQuizFinished(true);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh]">
        <BrainCircuit className="w-16 h-16 text-emerald-500 animate-pulse mb-4" />
        <p className="text-lg text-slate-600 font-medium">AI sedang menyusun soal untukmu...</p>
      </div>
    );
  }

  if (questions.length === 0 && !quizFinished) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-12 text-center">
        <div className="bg-white rounded-2xl shadow-xl p-8 border border-slate-100">
          <BrainCircuit className="w-16 h-16 text-emerald-600 mx-auto mb-6" />
          <h2 className="text-3xl font-bold text-slate-800 mb-4">Uji Pemahaman Stoikiometri</h2>
          <p className="text-slate-600 mb-8">Pilih tingkat kesulitan dan biarkan AI membuatkan kuis unik untukmu setiap saat.</p>
          
          <div className="flex justify-center space-x-4 mb-8">
            {(['easy', 'medium', 'hard'] as const).map(d => (
              <button
                key={d}
                onClick={() => setDifficulty(d)}
                className={`px-4 py-2 rounded-lg capitalize border ${difficulty === d ? 'bg-emerald-600 text-white border-emerald-600' : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'}`}
              >
                {d === 'easy' ? 'Mudah' : d === 'medium' ? 'Sedang' : 'Sulit'}
              </button>
            ))}
          </div>

          <button
            onClick={startQuiz}
            className="w-full sm:w-auto px-8 py-3 bg-emerald-600 text-white rounded-full font-bold shadow-lg hover:bg-emerald-700 hover:shadow-xl transition transform hover:-translate-y-1"
          >
            Mulai Kuis
          </button>
        </div>
      </div>
    );
  }

  if (quizFinished) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-12 text-center animate-fadeIn">
        <div className="bg-white rounded-2xl shadow-xl p-8 border border-slate-100">
          <Award className="w-20 h-20 text-yellow-500 mx-auto mb-6" />
          <h2 className="text-3xl font-bold text-slate-800 mb-2">Kuis Selesai!</h2>
          <p className="text-slate-600 mb-6">Kamu mendapatkan skor:</p>
          <div className="text-6xl font-bold text-emerald-600 mb-8">
            {Math.round((score / questions.length) * 100)}
          </div>
          <p className="text-slate-500 mb-8">Benar {score} dari {questions.length} soal</p>
          
          <button
            onClick={() => { setQuestions([]); }}
            className="flex items-center justify-center mx-auto px-6 py-3 border-2 border-slate-300 text-slate-700 font-bold rounded-lg hover:border-slate-800 hover:text-slate-800 transition"
          >
            <RotateCcw className="w-5 h-5 mr-2" />
            Coba Lagi
          </button>
        </div>
      </div>
    );
  }

  const currentQ = questions[currentIndex];

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <div className="bg-white rounded-2xl shadow-lg overflow-hidden border border-slate-200">
        {/* Progress Bar */}
        <div className="w-full bg-slate-100 h-2">
          <div 
            className="bg-emerald-500 h-2 transition-all duration-300" 
            style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
          ></div>
        </div>

        <div className="p-6 md:p-8">
          <div className="flex justify-between items-center mb-6">
            <span className="text-sm font-bold text-slate-400">Soal {currentIndex + 1} dari {questions.length}</span>
            <span className={`px-2 py-1 rounded text-xs font-bold uppercase ${difficulty === 'easy' ? 'bg-green-100 text-green-700' : difficulty === 'medium' ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'}`}>
              {difficulty}
            </span>
          </div>

          <h3 className="text-xl font-medium text-slate-800 mb-8 leading-relaxed">
            {currentQ.question}
          </h3>

          <div className="space-y-3">
            {currentQ.options.map((opt, idx) => {
              let btnClass = "w-full text-left p-4 rounded-xl border-2 transition-all duration-200 flex justify-between items-center ";
              
              if (isAnswered) {
                if (idx === currentQ.correctIndex) {
                  btnClass += "border-green-500 bg-green-50 text-green-800";
                } else if (idx === selectedOption) {
                  btnClass += "border-red-500 bg-red-50 text-red-800";
                } else {
                  btnClass += "border-slate-100 text-slate-400";
                }
              } else {
                btnClass += "border-slate-200 hover:border-emerald-500 hover:bg-slate-50 text-slate-700";
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleOptionClick(idx)}
                  disabled={isAnswered}
                  className={btnClass}
                >
                  <span>{opt}</span>
                  {isAnswered && idx === currentQ.correctIndex && <CheckCircle className="w-5 h-5 text-green-600" />}
                  {isAnswered && idx === selectedOption && idx !== currentQ.correctIndex && <XCircle className="w-5 h-5 text-red-600" />}
                </button>
              );
            })}
          </div>

          {isAnswered && (
            <div className="mt-6 animate-fadeIn">
              <div className="bg-blue-50 border border-blue-100 p-4 rounded-lg mb-6">
                <h4 className="font-bold text-blue-800 mb-1">Penjelasan:</h4>
                <p className="text-blue-700 text-sm">{currentQ.explanation}</p>
              </div>
              <div className="flex justify-end">
                <button
                  onClick={nextQuestion}
                  className="bg-emerald-600 text-white px-6 py-2 rounded-lg font-bold hover:bg-emerald-700 transition"
                >
                  {currentIndex === questions.length - 1 ? 'Lihat Hasil' : 'Lanjut'}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default QuizModule;
