export type ViewState = 'home' | 'learn' | 'tools' | 'tutor' | 'quiz';

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
  timestamp: number;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface QuizResult {
  score: number;
  total: number;
}

export interface EquationResponse {
  balancedEquation: string;
  steps: string[];
  molarMasses: Record<string, string>;
}
